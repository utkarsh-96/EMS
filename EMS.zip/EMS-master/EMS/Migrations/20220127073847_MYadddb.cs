﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EMS.Migrations
{
    public partial class MYadddb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
