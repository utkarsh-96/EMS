﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EMS.Migrations.Employee
{
    public partial class MyMigrationss : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
